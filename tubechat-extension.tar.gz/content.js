const API_BASE = "https://31d5fd0a-6834-4430-aba4-ec9b9880dc47-00-39s15ceewthwo.janeway.replit.dev/api";

let preferences = { blockedCategories: [], blockedKeywords: [], blockedChannels: [] };
let chatMessages = [];
let isOpen = false;
let isTyping = false;
let observer = null;

const YOUTUBE_CATEGORY_MAP = {
  music: ["music", "song", "lyrics", "official video", "mv", "vevo", "album", "single", "ft.", "feat."],
  gaming: ["gaming", "gameplay", "let's play", "walkthrough", "playthrough", "speedrun", "gamer", "fortnite", "minecraft", "roblox", "cod", "valorant"],
  news: ["news", "breaking", "report", "cnn", "fox news", "bbc", "nbc", "abc news", "msnbc", "politics", "election"],
  sports: ["nfl", "nba", "mlb", "nhl", "soccer", "football", "basketball", "baseball", "tennis", "golf", "highlights", "match", "game recap"],
  comedy: ["comedy", "funny", "hilarious", "meme", "roast", "stand-up", "sketch"],
  education: ["tutorial", "how to", "learn", "course", "explained", "education", "lesson"],
  entertainment: ["trailer", "reaction", "celebrity", "interview", "talk show", "entertainment tonight"],
};

async function loadPreferences() {
  try {
    const stored = await new Promise(resolve => chrome.storage.local.get("preferences", resolve));
    if (stored.preferences) {
      preferences = stored.preferences;
    } else {
      const res = await fetch(`${API_BASE}/youtube/preferences`);
      if (res.ok) {
        const data = await res.json();
        preferences = data;
        chrome.storage.local.set({ preferences });
      }
    }
  } catch (e) {
    console.log("[TubeChat] Could not load preferences:", e);
  }
}

async function savePreferences(newPrefs) {
  preferences = newPrefs;
  chrome.storage.local.set({ preferences });
  try {
    await fetch(`${API_BASE}/youtube/preferences`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(newPrefs),
    });
  } catch (e) {
    console.log("[TubeChat] Could not sync preferences:", e);
  }
}

function isVideoBlocked(titleEl, channelEl) {
  const title = (titleEl?.textContent || "").toLowerCase();
  const channel = (channelEl?.textContent || "").toLowerCase();

  for (const keyword of preferences.blockedKeywords || []) {
    if (title.includes(keyword.toLowerCase())) return { blocked: true, reason: `keyword: "${keyword}"` };
  }

  for (const ch of preferences.blockedChannels || []) {
    if (channel.includes(ch.toLowerCase())) return { blocked: true, reason: `channel: "${ch}"` };
  }

  for (const cat of preferences.blockedCategories || []) {
    const keywords = YOUTUBE_CATEGORY_MAP[cat.toLowerCase()] || [cat.toLowerCase()];
    for (const kw of keywords) {
      if (title.includes(kw)) return { blocked: true, reason: `category: ${cat}` };
    }
  }

  return { blocked: false };
}

function hideBlockedVideos() {
  const hasPrefs =
    (preferences.blockedCategories?.length > 0) ||
    (preferences.blockedKeywords?.length > 0) ||
    (preferences.blockedChannels?.length > 0);

  if (!hasPrefs) return;

  // Home page video cards
  const videoRenderers = document.querySelectorAll("ytd-rich-item-renderer, ytd-video-renderer, ytd-compact-video-renderer");

  videoRenderers.forEach(renderer => {
    if (renderer.dataset.tubechatProcessed) return;
    renderer.dataset.tubechatProcessed = "1";

    const titleEl = renderer.querySelector("#video-title");
    const channelEl = renderer.querySelector("ytd-channel-name, #channel-name, .ytd-channel-name");
    const result = isVideoBlocked(titleEl, channelEl);

    if (result.blocked) {
      renderer.style.display = "none";
      renderer.dataset.tubechatBlocked = result.reason;
    }
  });
}

function resetVideoVisibility() {
  document.querySelectorAll("[data-tubechat-blocked]").forEach(el => {
    el.style.display = "";
    delete el.dataset.tubechatBlocked;
    delete el.dataset.tubechatProcessed;
  });
  document.querySelectorAll("[data-tubechat-processed]").forEach(el => {
    delete el.dataset.tubechatProcessed;
  });
}

function startObserver() {
  if (observer) observer.disconnect();
  observer = new MutationObserver(() => {
    hideBlockedVideos();
  });
  observer.observe(document.body, { childList: true, subtree: true });
}

function createPanel() {
  const panel = document.createElement("div");
  panel.id = "tubechat-panel";
  panel.innerHTML = `
    <div id="tubechat-header">
      <div id="tubechat-title">
        <span class="tubechat-dot"></span>
        TubeChat AI
      </div>
      <button id="tubechat-close" title="Close">✕</button>
    </div>
    <div id="tubechat-messages">
      <div class="tubechat-msg assistant">
        <div class="tubechat-bubble">
          Hi! I'm your YouTube AI assistant. Tell me what you want to watch, or ask me to filter out content you don't like.<br><br>
          <span class="tubechat-hint">Try: "hide music videos" or "show me science documentaries"</span>
        </div>
      </div>
    </div>
    <div id="tubechat-filters" style="display:none">
      <span class="tubechat-filter-label">Blocked:</span>
      <div id="tubechat-filter-chips"></div>
    </div>
    <div id="tubechat-input-row">
      <input id="tubechat-input" type="text" placeholder="Ask me anything about YouTube..." autocomplete="off" />
      <button id="tubechat-send">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M2.01 21L23 12 2.01 3 2 10l15 2-15 2z"/></svg>
      </button>
    </div>
  `;
  return panel;
}

function createToggleButton() {
  const btn = document.createElement("button");
  btn.id = "tubechat-toggle";
  btn.title = "TubeChat AI";
  btn.innerHTML = `
    <svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor">
      <path d="M20 2H4c-1.1 0-2 .9-2 2v18l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zm-2 12H6v-2h12v2zm0-3H6V9h12v2zm0-3H6V6h12v2z"/>
    </svg>
  `;
  return btn;
}

function renderMessages() {
  const container = document.getElementById("tubechat-messages");
  if (!container) return;

  const existing = container.querySelectorAll(".tubechat-msg");
  const startIdx = existing.length;

  chatMessages.slice(startIdx).forEach(msg => {
    const div = document.createElement("div");
    div.className = `tubechat-msg ${msg.role}`;

    let content = msg.content || "";

    // Remove the JSON action line from display
    const lines = content.trim().split("\n");
    const lastLine = lines[lines.length - 1].trim();
    if (lastLine.startsWith("{") && lastLine.includes('"action"')) {
      content = lines.slice(0, -1).join("\n").trim();
    }

    div.innerHTML = `<div class="tubechat-bubble">${content.replace(/\n/g, "<br>")}</div>`;
    container.appendChild(div);
  });

  container.scrollTop = container.scrollHeight;
}

function showTyping() {
  const container = document.getElementById("tubechat-messages");
  if (!container || document.getElementById("tubechat-typing")) return;
  const div = document.createElement("div");
  div.id = "tubechat-typing";
  div.className = "tubechat-msg assistant";
  div.innerHTML = `<div class="tubechat-bubble"><span class="tubechat-dots"><span></span><span></span><span></span></span></div>`;
  container.appendChild(div);
  container.scrollTop = container.scrollHeight;
}

function hideTyping() {
  document.getElementById("tubechat-typing")?.remove();
}

function updateFilterChips() {
  const filtersEl = document.getElementById("tubechat-filters");
  const chipsEl = document.getElementById("tubechat-filter-chips");
  if (!filtersEl || !chipsEl) return;

  const allBlocked = [
    ...(preferences.blockedCategories || []).map(c => ({ label: c, type: "category" })),
    ...(preferences.blockedKeywords || []).map(k => ({ label: k, type: "keyword" })),
    ...(preferences.blockedChannels || []).map(c => ({ label: c, type: "channel" })),
  ];

  if (allBlocked.length === 0) {
    filtersEl.style.display = "none";
    return;
  }

  filtersEl.style.display = "flex";
  chipsEl.innerHTML = allBlocked.map(b =>
    `<span class="tubechat-chip" data-label="${b.label}" data-type="${b.type}">
      ${b.label} <button class="tubechat-chip-remove" data-label="${b.label}" data-type="${b.type}">×</button>
    </span>`
  ).join("");

  chipsEl.querySelectorAll(".tubechat-chip-remove").forEach(btn => {
    btn.addEventListener("click", async (e) => {
      e.stopPropagation();
      const label = btn.dataset.label;
      const type = btn.dataset.type;
      const newPrefs = {
        blockedCategories: type === "category"
          ? preferences.blockedCategories.filter(c => c !== label)
          : preferences.blockedCategories,
        blockedKeywords: type === "keyword"
          ? preferences.blockedKeywords.filter(k => k !== label)
          : preferences.blockedKeywords,
        blockedChannels: type === "channel"
          ? preferences.blockedChannels.filter(c => c !== label)
          : preferences.blockedChannels,
      };
      await savePreferences(newPrefs);
      resetVideoVisibility();
      hideBlockedVideos();
      updateFilterChips();
      appendAssistantMessage(`Removed "${label}" from your blocked ${type}s. Those videos will appear again.`);
    });
  });
}

function appendAssistantMessage(text) {
  const msg = { role: "assistant", content: text };
  chatMessages.push(msg);
  renderMessages();
}

async function sendMessage(text) {
  if (!text.trim() || isTyping) return;

  const input = document.getElementById("tubechat-input");
  if (input) input.value = "";

  chatMessages.push({ role: "user", content: text });
  renderMessages();

  isTyping = true;
  showTyping();

  try {
    const response = await fetch(`${API_BASE}/youtube/chat`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ message: text }),
    });

    if (!response.ok) throw new Error("API error");

    const reader = response.body?.getReader();
    const decoder = new TextDecoder();
    let assistantText = "";
    let videoResults = null;
    let prefUpdate = null;

    hideTyping();

    const assistantMsg = { role: "assistant", content: "" };
    chatMessages.push(assistantMsg);
    renderMessages();

    let buffer = "";

    while (true) {
      const { done, value } = await reader.read();
      if (done) break;

      buffer += decoder.decode(value, { stream: true });
      const lines = buffer.split("\n");
      buffer = lines.pop();

      for (const line of lines) {
        if (!line.startsWith("data: ")) continue;
        try {
          const data = JSON.parse(line.slice(6));

          if (data.type === "text" && data.content) {
            assistantText += data.content;
            // Strip JSON action line from display
            let displayText = assistantText;
            const dlines = displayText.trim().split("\n");
            const last = dlines[dlines.length - 1].trim();
            if (last.startsWith("{") && last.includes('"action"')) {
              displayText = dlines.slice(0, -1).join("\n").trim();
            }
            assistantMsg.content = displayText;
            const msgs = document.querySelectorAll("#tubechat-messages .tubechat-msg.assistant");
            const lastMsg = msgs[msgs.length - 1];
            if (lastMsg) {
              lastMsg.querySelector(".tubechat-bubble").innerHTML = displayText.replace(/\n/g, "<br>");
            }
            document.getElementById("tubechat-messages").scrollTop = 99999;
          }

          if (data.type === "videos") {
            videoResults = data.videos;
          }

          if (data.type === "preference_update") {
            prefUpdate = data.preferences;
          }

          if (data.done) {
            isTyping = false;

            if (prefUpdate) {
              preferences = prefUpdate;
              chrome.storage.local.set({ preferences: prefUpdate });
              resetVideoVisibility();
              hideBlockedVideos();
              updateFilterChips();
            }

            if (videoResults && videoResults.length > 0) {
              showVideoResults(videoResults);
            }

            if (videoResults && videoResults.length === 0) {
              appendAssistantMessage("No videos found matching that. Try a different search.");
            }
          }
        } catch (_) {}
      }
    }

    isTyping = false;
    hideTyping();

  } catch (err) {
    hideTyping();
    isTyping = false;
    appendAssistantMessage("Something went wrong connecting to the AI. Please try again.");
    console.log("[TubeChat] Error:", err);
  }
}

function showVideoResults(videos) {
  const container = document.getElementById("tubechat-messages");
  if (!container) return;

  const div = document.createElement("div");
  div.className = "tubechat-msg assistant";
  div.innerHTML = `
    <div class="tubechat-bubble tubechat-results">
      <div class="tubechat-results-label">Found ${videos.length} video${videos.length !== 1 ? "s" : ""}:</div>
      ${videos.slice(0, 5).map(v => `
        <a class="tubechat-video-card" href="https://www.youtube.com/watch?v=${v.videoId}" target="_blank">
          <img src="${v.thumbnailUrl}" alt="${escapeHtml(v.title)}" onerror="this.style.display='none'"/>
          <div class="tubechat-video-info">
            <div class="tubechat-video-title">${escapeHtml(v.title)}</div>
            <div class="tubechat-video-channel">${escapeHtml(v.channelTitle)}</div>
          </div>
        </a>
      `).join("")}
    </div>
  `;
  container.appendChild(div);
  container.scrollTop = 99999;
}

function escapeHtml(str) {
  return (str || "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}

function initPanel() {
  if (document.getElementById("tubechat-panel")) return;

  const panel = createPanel();
  const toggle = createToggleButton();

  document.body.appendChild(panel);
  document.body.appendChild(toggle);

  toggle.addEventListener("click", () => {
    isOpen = !isOpen;
    panel.classList.toggle("tubechat-open", isOpen);
    if (isOpen) {
      updateFilterChips();
      document.getElementById("tubechat-input")?.focus();
    }
  });

  document.getElementById("tubechat-close").addEventListener("click", () => {
    isOpen = false;
    panel.classList.remove("tubechat-open");
  });

  const input = document.getElementById("tubechat-input");
  input.addEventListener("keydown", (e) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      sendMessage(input.value);
    }
  });

  document.getElementById("tubechat-send").addEventListener("click", () => {
    sendMessage(input.value);
  });
}

async function init() {
  await loadPreferences();
  initPanel();
  hideBlockedVideos();
  startObserver();
  updateFilterChips();
}

// Wait for YouTube to finish rendering before injecting
if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", init);
} else {
  init();
}

// Re-run on YouTube navigation (YouTube is an SPA)
let lastUrl = location.href;
new MutationObserver(() => {
  const url = location.href;
  if (url !== lastUrl) {
    lastUrl = url;
    setTimeout(() => {
      document.querySelectorAll("[data-tubechat-processed]").forEach(el => {
        delete el.dataset.tubechatProcessed;
      });
      hideBlockedVideos();
    }, 1500);
  }
}).observe(document.body, { subtree: true, childList: true });
